const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.post('/submit-location', (req, res) => {
    const latitude = req.body.latitude;
    const longitude = req.body.longitude;

    // Handle the received location data
    console.log(`Received location: Latitude = ${latitude}, Longitude = ${longitude}`);

    res.send('Location received successfully!');
});

const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});